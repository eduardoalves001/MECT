import matplotlib.pyplot as plt
import csv
import sys
from collections import defaultdict

def main():
    if len(sys.argv) < 2:
        print("Usage: python plot_obu.py <obu_metrics_file.csv>")
        sys.exit(1)
        
    filename = sys.argv[1]
    # Dictionary to collect data for each node
    node_data = defaultdict(list)
    
    with open(filename, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                ts = float(row['timestamp'])
                node = row['node_id']
                progress = float(row['progress'])
                node_data[node].append((ts, progress))
            except Exception as e:
                print("Error parsing row:", row, e)
                continue

    plt.figure(figsize=(12, 7))
    for node, points in node_data.items():
        # Sort points by time 
        points.sort(key=lambda x: x[0])
        times, progresses = zip(*points)
        if node == "101":
            label = f'RSU {node}'
        else:
            label = f'OBU {node}'
        plt.plot(times, progresses, label=label)
    
    plt.xlabel("Time (seconds)")
    plt.ylabel("Download Percentage (%)")
    plt.title("Download Percentage Over Time for Each Node")
    plt.grid(True)
    plt.legend(fontsize='small', ncol=2)
    plt.show()

if __name__ == "__main__":
    main()