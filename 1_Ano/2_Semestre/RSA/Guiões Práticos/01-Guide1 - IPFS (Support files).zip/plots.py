import matplotlib.pyplot as plt
import csv
import sys
from collections import defaultdict

def process_file(filename):
    # Dictionary to collect data for each node
    node_data = defaultdict(list)
    
    with open(filename, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                ts = float(row['timestamp'])
                # Adjust field names if needed
                node = row.get('node_id', row.get('id', 'unknown'))
                progress = float(row.get('progress', row.get('progress_percent', 0)))
                node_data[node].append((ts, progress))
            except Exception as e:
                print("Error parsing row:", row, e)
                continue
    return node_data

def plot_data(ax, node_data, title):
    for node, points in node_data.items():
        # Sort points by time
        points.sort(key=lambda x: x[0])
        times, progresses = zip(*points)
        label = f'RSU {node}' if node == "101" else f'OBU {node}'
        ax.plot(times, progresses, label=label)
    
    ax.set_xlabel("Time (seconds)")
    ax.set_ylabel("Download Percentage (%)")
    ax.set_title(title)
    ax.grid(True)
    ax.legend(fontsize='small', ncol=2)

def main():
    if len(sys.argv) < 3:
        print("Usage: python plot_obu.py <bitTorrent_obu_metrics_file.csv> <ipfs_obu_metrics_file.csv>")
        sys.exit(1)
        
    file_bt = sys.argv[1]
    file_ipfs = sys.argv[2]
    
    # Process both files
    bt_data = process_file(file_bt)
    ipfs_data = process_file(file_ipfs)
    
    # Create a single figure with two subplots
    fig, axs = plt.subplots(1, 2, figsize=(16, 7))
    
    plot_data(axs[0], bt_data, "BitTorrent: Download Percentage Over Time")
    plot_data(axs[1], ipfs_data, "IPFS: Download Percentage Over Time")
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()